<?php 

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', function()
{
	return View::make('hello');
});


Route::resource('softwaremodel', 'SoftwareModelController');
Route::resource('softsubscriptionmodel', 'SoftSubscriptionModelController');
Route::resource('softwarebrandsmodel', 'SoftwareBrandsModelController');
Route::resource('softwareproductsmodel', 'SoftwareProductsModelController');
Route::resource('subscriptiontypesmodel', 'SubscriptionTypesModelController');
Route::resource('softwareinstalledmodel', 'SoftwareInstalledModelController');
Route::resource('softwarefeatures', 'SoftwareFeaturesController');
Route::resource('softwareuppdatesmodel', 'SoftwareUppdatesModelController');
Route::resource('softwareaddonsmodel', 'SoftwareAddonsModelController');
