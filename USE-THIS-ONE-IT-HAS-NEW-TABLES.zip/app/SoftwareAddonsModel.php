<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SoftwareAddonsModel extends Model {

	protected $table = 'software_addons';
	public $timestamps = true;

	use SoftDeletes;

	protected $dates = ['deleted_at'];
	protected $fillable = array('soft_addon_name', 'soft_addon_details', 'soft_addon_available', 'soft_addon_status');
	protected $visible = array('soft_addon_name', 'soft_addon_details', 'soft_addon_available', 'soft_addon_status');

	public function soft_addon_con()
	{
		return $this->hasOne('App\SoftwareModel', 'id');
	}

}