<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SoftwareFeatures extends Model {

	protected $table = 'software_features';
	public $timestamps = true;

	use SoftDeletes;

	protected $dates = ['deleted_at'];
	protected $fillable = array('feature_title', 'feature_desc');
	protected $visible = array('feature_title', 'feature_desc', 'software_feature_id');

}