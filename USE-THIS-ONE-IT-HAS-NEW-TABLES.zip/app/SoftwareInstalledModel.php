<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SoftwareInstalledModel extends Model {

	protected $table = 'software_installed';
	public $timestamps = true;

	use SoftDeletes;

	protected $dates = ['deleted_at'];
	protected $fillable = array('device_one', 'device_two', 'device_three');
	protected $visible = array('device_one', 'device_two', 'device_three');

	public function software()
	{
		return $this->hasMany('App\SoftwareModel', 'soft_product', 'soft_id');
	}

}