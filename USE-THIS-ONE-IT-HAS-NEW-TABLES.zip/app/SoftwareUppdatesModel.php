<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SoftwareUppdatesModel extends Model {

	protected $table = 'software_updates';
	public $timestamps = true;

	use SoftDeletes;

	protected $dates = ['deleted_at'];
	protected $fillable = array('update_name', 'update_url', 'update_package');
	protected $visible = array('soft_update_id', 'issued_date', 'update_name', 'update_url', 'update_package');

	public function software_update_id()
	{
		return $this->belongsTo('App\SoftwareModel', 'id');
	}

}