<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class CreateForeignKeys extends Migration {

	public function up()
	{
		Schema::table('software', function(Blueprint $table) {
			$table->foreign('soft_id')->references('id')->on('software')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
		Schema::table('soft_subscription', function(Blueprint $table) {
			$table->foreign('subs_id')->references('id')->on('software')
						->onDelete('no action')
						->onUpdate('cascade');
		});
		Schema::table('soft_subscription', function(Blueprint $table) {
			$table->foreign('renew_every')->references('subsc_term_months')->on('subscr_types')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
		Schema::table('soft_brands', function(Blueprint $table) {
			$table->foreign('brand_id')->references('id')->on('software')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
		Schema::table('soft_products', function(Blueprint $table) {
			$table->foreign('soft_prod_id')->references('id')->on('software')
						->onDelete('no action')
						->onUpdate('cascade');
		});
		Schema::table('subscr_types', function(Blueprint $table) {
			$table->foreign('subs_type_id')->references('id')->on('soft_subscription')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
		Schema::table('software_installed', function(Blueprint $table) {
			$table->foreign('inst_soft_id')->references('id')->on('soft_products')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
		Schema::table('software_features', function(Blueprint $table) {
			$table->foreign('software_feature_id')->references('id')->on('software')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
		Schema::table('software_updates', function(Blueprint $table) {
			$table->foreign('soft_update_id')->references('id')->on('software')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
		Schema::table('software_addons', function(Blueprint $table) {
			$table->foreign('soft_addon_id')->references('id')->on('software')
						->onDelete('cascade')
						->onUpdate('cascade');
		});
	}

	public function down()
	{
		Schema::table('software', function(Blueprint $table) {
			$table->dropForeign('software_soft_id_foreign');
		});
		Schema::table('soft_subscription', function(Blueprint $table) {
			$table->dropForeign('soft_subscription_subs_id_foreign');
		});
		Schema::table('soft_subscription', function(Blueprint $table) {
			$table->dropForeign('soft_subscription_renew_every_foreign');
		});
		Schema::table('soft_brands', function(Blueprint $table) {
			$table->dropForeign('soft_brands_brand_id_foreign');
		});
		Schema::table('soft_products', function(Blueprint $table) {
			$table->dropForeign('soft_products_soft_prod_id_foreign');
		});
		Schema::table('subscr_types', function(Blueprint $table) {
			$table->dropForeign('subscr_types_subs_type_id_foreign');
		});
		Schema::table('software_installed', function(Blueprint $table) {
			$table->dropForeign('software_installed_inst_soft_id_foreign');
		});
		Schema::table('software_features', function(Blueprint $table) {
			$table->dropForeign('software_features_software_feature_id_foreign');
		});
		Schema::table('software_updates', function(Blueprint $table) {
			$table->dropForeign('software_updates_soft_update_id_foreign');
		});
		Schema::table('software_addons', function(Blueprint $table) {
			$table->dropForeign('software_addons_soft_addon_id_foreign');
		});
	}
}