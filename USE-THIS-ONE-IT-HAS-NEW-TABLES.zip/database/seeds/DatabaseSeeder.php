<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder {

	public function run()
	{
		Model::unguard();

		$this->call('SoftwareBrandsModelTableSeeder');
		$this->command->info('SoftwareBrandsModel table seeded!');

		$this->call('SoftwareProductsModelTableSeeder');
		$this->command->info('SoftwareProductsModel table seeded!');

		$this->call('SubscriptionTypesModelTableSeeder');
		$this->command->info('SubscriptionTypesModel table seeded!');
	}
}