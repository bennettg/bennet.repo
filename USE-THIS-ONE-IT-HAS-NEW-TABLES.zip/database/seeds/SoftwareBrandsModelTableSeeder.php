<?php

use Illuminate\Database\Seeder;
use App\SoftwareBrandsModel;

class SoftwareBrandsModelTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('soft_brands')->delete();

		// SeedBabylock
		SoftwareBrandsModel::create(array(
				'code' => 'BAB',
				'brand_name' => 'Babylock'
			));

		// SeedBlockRockit
		SoftwareBrandsModel::create(array(
				'code' => 'BKR',
				'brand_name' => 'Block Rockit'
			));

		// SeedBrandAPQS
		SoftwareBrandsModel::create(array(
				'code' => 'APQ',
				'brand_name' => 'APQS'
			));

		// SeedBernina
		SoftwareBrandsModel::create(array(
				'code' => 'BER',
				'brand_name' => 'Bernina'
			));

		// SeedJanome
		SoftwareBrandsModel::create(array(
				'code' => 'JAN',
				'brand_name' => 'Janome'
			));

		// SeedJuki
		SoftwareBrandsModel::create(array(
				'code' => 'JUK',
				'brand_name' => 'Juki'
			));

		// SeedNolting
		SoftwareBrandsModel::create(array(
				'code' => 'NOL',
				'brand_name' => 'Nolting'
			));

		// SeedQuiltMotion
		SoftwareBrandsModel::create(array(
				'code' => 'QMO',
				'brand_name' => 'Quilt Motion'
			));

		// SeedTailorBird
		SoftwareBrandsModel::create(array(
				'code' => 'TAI',
				'brand_name' => 'Tailor Bird'
			));

		// Design
		SoftwareBrandsModel::create(array(
				'code' => 'QCD',
				'brand_name' => 'Quilt CAD Design'
			));
	}
}