<?php

use Illuminate\Database\Seeder;
use App\SoftwareProductsModel;

class SoftwareProductsModelTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('soft_products')->delete();

		// SeedQuiltersCreativeTouch
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'QCT',
				'soft_product_name' => 'Quilters Creative Touch',
				'soft_product_type' => 'base'
			));

		// SeedQCTBasicUpgrade
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'UPG',
				'soft_product_name' => 'QCT Basic Upgrade',
				'soft_product_type' => 'addon'
			));

		// SeedQCTGold
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'SQC',
				'soft_product_name' => 'QCT Gold',
				'soft_product_type' => 'subscription'
			));

		// SeedQuiltersCreativeTouchF
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'FUL',
				'soft_product_name' => 'Quilters Creative Touch Foundation',
				'soft_product_type' => 'base'
			));

		// SeedQuiltersCreativeTouchB
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'LIM',
				'soft_product_name' => 'Quilters Creative Touch Basic',
				'soft_product_type' => 'base'
			));

		// SeedQCTBeginningsBronze
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'QBB',
				'soft_product_name' => 'QCT Begginings Bronze',
				'soft_product_type' => 'base'
			));

		// SeedQCTBeginningsSilver
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'SQB',
				'soft_product_name' => 'QCT Beginnings Silver',
				'soft_product_type' => 'subscription'
			));

		// SeedQCTBeginningsGold
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'GQB',
				'soft_product_name' => 'QCT Beginnings Gold',
				'soft_product_type' => 'subscription'
			));

		// 'SeedQCTBeginningsUpgradeGold'
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'QBU',
				'soft_product_name' => 'QCT Beginnings Gold Upgrade',
				'soft_product_type' => 'addon'
			));

		// SeedQCTBeginningsUpgradeBronze
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'UBB',
				'soft_product_name' => 'QCT Beginnings Bronze Upgrade',
				'soft_product_type' => 'subscription'
			));

		// SeedQCTBeginningsUpgradeSilver
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'UBS',
				'soft_product_name' => 'QCT Beginnings Silver Upgrade',
				'soft_product_type' => 'subscription'
			));

		// SeedQCTBeginningsUpgradePlatnum
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'UBP',
				'soft_product_name' => 'QCT Beginnings Platinum Upgrade',
				'soft_product_type' => 'subscription'
			));

		// SeedQCTBeginningsPlatnum
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'QBP',
				'soft_product_name' => 'QCT Beginnings Platnum',
				'soft_product_type' => 'subscription'
			));

		// SeedQuiltersCreativeDesignBronze
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'DSB',
				'soft_product_name' => 'Quilters Creative Design Bronze',
				'soft_product_type' => 'base'
			));

		// SeedSoftwareDemo
		SoftwareProductsModel::create(array(
				'soft_product_code' => 'DEM',
				'soft_product_name' => 'Software Demo',
				'soft_product_type' => 'demo'
			));
	}
}