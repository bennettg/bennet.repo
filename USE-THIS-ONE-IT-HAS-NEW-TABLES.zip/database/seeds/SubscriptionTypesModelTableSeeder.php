<?php

use Illuminate\Database\Seeder;
use App\SubscriptionTypesModel;

class SubscriptionTypesModelTableSeeder extends Seeder {

	public function run()
	{
		//DB::table('subscr_types')->delete();

		// SeedBronze
		SubscriptionTypesModel::create(array(
				'subsc_name' => 'Bronze',
				'subsc_term_months' => '12'
			));

		// SeedSilver
		SubscriptionTypesModel::create(array(
				'subsc_name' => 'Silver',
				'subsc_term_months' => '6'
			));

		// SeedGold
		SubscriptionTypesModel::create(array(
				'subsc_name' => 'Gold',
				'subsc_term_months' => '3'
			));

		// SeedPlatnum
		SubscriptionTypesModel::create(array(
				'subsc_name' => 'Platnum',
				'subsc_term_months' => '1'
			));
	}
}