{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('soft_product_code', 'Soft_product_code:') !!}
			{!! Form::text('soft_product_code') !!}
		</li>
		<li>
			{!! Form::label('soft_product_name', 'Soft_product_name:') !!}
			{!! Form::text('soft_product_name') !!}
		</li>
		<li>
			{!! Form::label('soft_product_type', 'Soft_product_type:') !!}
			{!! Form::text('soft_product_type') !!}
		</li>
		<li>
			{!! Form::label('soft_prod_id', 'Soft_prod_id:') !!}
			{!! Form::text('soft_prod_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}