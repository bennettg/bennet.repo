{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('soft_addon_id', 'Soft_addon_id:') !!}
			{!! Form::text('soft_addon_id') !!}
		</li>
		<li>
			{!! Form::label('soft_addon_name', 'Soft_addon_name:') !!}
			{!! Form::text('soft_addon_name') !!}
		</li>
		<li>
			{!! Form::label('soft_addon_details', 'Soft_addon_details:') !!}
			{!! Form::text('soft_addon_details') !!}
		</li>
		<li>
			{!! Form::label('soft_addon_available', 'Soft_addon_available:') !!}
			{!! Form::text('soft_addon_available') !!}
		</li>
		<li>
			{!! Form::label('soft_addon_status', 'Soft_addon_status:') !!}
			{!! Form::text('soft_addon_status') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}