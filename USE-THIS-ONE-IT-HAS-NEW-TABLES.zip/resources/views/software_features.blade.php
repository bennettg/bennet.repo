{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('feature_title', 'Feature_title:') !!}
			{!! Form::text('feature_title') !!}
		</li>
		<li>
			{!! Form::label('feature_desc', 'Feature_desc:') !!}
			{!! Form::text('feature_desc') !!}
		</li>
		<li>
			{!! Form::label('software_feature_id', 'Software_feature_id:') !!}
			{!! Form::text('software_feature_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}