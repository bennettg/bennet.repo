{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('soft_update_id', 'Soft_update_id:') !!}
			{!! Form::text('soft_update_id') !!}
		</li>
		<li>
			{!! Form::label('issued_date', 'Issued_date:') !!}
			{!! Form::text('issued_date') !!}
		</li>
		<li>
			{!! Form::label('update_name', 'Update_name:') !!}
			{!! Form::text('update_name') !!}
		</li>
		<li>
			{!! Form::label('update_url', 'Update_url:') !!}
			{!! Form::text('update_url') !!}
		</li>
		<li>
			{!! Form::label('update_package', 'Update_package:') !!}
			{!! Form::text('update_package') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}