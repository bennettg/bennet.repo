<?php

//Constants File

/**
 * App error code constants
 */
define('ERROR_CODE_VALIDATION_FAILED', 1001);
define('ERROR_CODE_RECORD_NOT_FOUND', 1111);