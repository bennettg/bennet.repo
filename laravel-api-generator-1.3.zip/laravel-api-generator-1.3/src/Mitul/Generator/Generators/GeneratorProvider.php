<?php
/**
 * User: Mitul
 * Date: 14/02/15
 * Time: 4:53 PM
 */

namespace Mitul\Generator\Generators;


interface GeneratorProvider
{
	function generate();
}