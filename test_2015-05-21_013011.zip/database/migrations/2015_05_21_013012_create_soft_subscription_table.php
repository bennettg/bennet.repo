<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSoftSubscriptionTable extends Migration {

	public function up()
	{
		Schema::create('soft_subscription', function(Blueprint $table) {
			$table->increments('id');
			$table->timestamps();
			$table->softDeletes();
			$table->enum('subscr_active', array('NO', 'YES'))->index();
			$table->integer('subs_id')->unsigned();
			$table->integer('renew_every')->unsigned();
		});
	}

	public function down()
	{
		Schema::drop('soft_subscription');
	}
}