{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('inst_soft_id', 'Inst_soft_id:') !!}
			{!! Form::text('inst_soft_id') !!}
		</li>
		<li>
			{!! Form::label('device_one', 'Device_one:') !!}
			{!! Form::text('device_one') !!}
		</li>
		<li>
			{!! Form::label('device_two', 'Device_two:') !!}
			{!! Form::text('device_two') !!}
		</li>
		<li>
			{!! Form::label('device_three', 'Device_three:') !!}
			{!! Form::text('device_three') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}