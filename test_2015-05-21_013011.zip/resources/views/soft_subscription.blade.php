{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('subscr_active', 'Subscr_active:') !!}
			{!! Form::text('subscr_active') !!}
		</li>
		<li>
			{!! Form::label('subs_id', 'Subs_id:') !!}
			{!! Form::text('subs_id') !!}
		</li>
		<li>
			{!! Form::label('renew_every', 'Renew_every:') !!}
			{!! Form::text('renew_every') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}